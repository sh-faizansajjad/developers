export const box1 = "https://preview.colorlib.com/theme/rezume/images/p1.jpg";
export const box2 = "https://preview.colorlib.com/theme/rezume/images/p2.jpg";
export const box3 = "https://preview.colorlib.com/theme/rezume/images/p3.jpg";
export const box4 = "https://preview.colorlib.com/theme/rezume/images/p4.jpg";
export const box5 = "https://preview.colorlib.com/theme/rezume/images/p5.jpg";
export const box6 = "https://preview.colorlib.com/theme/rezume/images/p6.jpg";
export const intro =
  "https://preview.colorlib.com/theme/rezume/images/image_1.jpg";
export const blog1 =
  "https://preview.colorlib.com/theme/rezume/images/post_1.jpg";
export const blog2 =
  "https://preview.colorlib.com/theme/rezume/images/post_2.jpg";
export const blog3 =
  "https://preview.colorlib.com/theme/rezume/images/post_3.jpg";
