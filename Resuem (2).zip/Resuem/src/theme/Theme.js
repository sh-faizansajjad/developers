import { ThemeProvider } from "styled-components";
import React from "react";

export const theme = {
  boxColor: "rgb(51,51,51)",
  btnBgClr1: "rgb(200,210,100)",
  btnBgClr: "rgb(108,117,125)",
  lightTheme: {
    bgColor: "#f3f3f3",
    textColor: "black",
  },

  darkTheme: {
    bgColor: "rgb(34,34,34)",
    textColor: "#D8D8D8",
  },
};

const Theme = ({ children }) => {
  return <ThemeProvider theme={theme}>{children}</ThemeProvider>;
};

export default Theme;
