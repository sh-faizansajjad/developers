import React from "react";
import AboutMe from "./components/AboutMe";
import Blogs from "./components/Blogs";
import Footer from "./components/Footer";
import GetTouch from "./components/GetTouch";
import Introduction from "./components/Introduction";
import Portfolio from "./components/Portfolio";
import Services from "./components/Services";
import { GlobelStyle } from "./styledComponents/globelStyle/Globle.styled";
import Theme from "./theme/Theme";

const App = () => {
  return (
    <div>
      <Theme>
        <GlobelStyle />
        <Introduction />
        <Portfolio />
        <AboutMe />
        <Services />
        <Blogs />
        <GetTouch />
        <Footer />
      </Theme>
    </div>
  );
};

export default App;
