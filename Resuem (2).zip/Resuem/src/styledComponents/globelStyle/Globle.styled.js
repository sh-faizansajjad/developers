import { createGlobalStyle } from "styled-components";

export const GlobelStyle = createGlobalStyle`
 *{
    margin : 0px;
    padding : 0px;
    box-sizing: border-box;
}

body{
    background-color: ${(props) => props.theme.darkTheme.bgColor};
    color : ${(props) => props.theme.darkTheme.textColor};
    @media only screen and (max-width : 768px){
        background-color: ${(props) => props.theme.lightTheme.bgColor};
        color : ${(props) => props.theme.lightTheme.textColor};
    };

}

`;
