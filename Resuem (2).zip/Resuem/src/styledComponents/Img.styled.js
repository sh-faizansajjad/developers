import styled from "styled-components";

export const Image = styled.img`
  width: 90%;
`;

export const AboutImage = styled.img`
  width: 100%;
`;
