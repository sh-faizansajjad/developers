import styled from "styled-components";
import { intro } from "../utils";

export const Container = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  justify-content: space-around;
  align-items: center;
  flex-direction: column;
  background-image: url(${intro});
  background-repeat: no-repeat;
  background-size: 100%;

  & .menu {
    width: 700px;
    font-size: 22px;
    padding: 20px;
    color: white;
    border-radius: 25px;

    & ul > li {
      display: inline-block;
      margin: 0px 15px;
    }
  }
  & > .text {
    color: white;
    font-size: 22px;

    width: 400px;
    padding: 20px;
    margin: 10px;
    text-align: center;
  }

  @media only screen and (max-width: 600px) {
    & .menu,
    .text {
      width: 400px;
      font-size: 10px;
    }
  }
`;

export const ContainerPadding = styled.div`
  width: 100%;
  padding: 50px 0px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;

  & > div {
    margin: 30px 0px;
    & ul > li {
      display: inline-block;
      margin: 0px 20px;
    }
  }

  @media only screen and (max-width: 768px) {
    padding: 10px 0px;
    & > div {
      margin: 10px 0px;
    }
  }
`;

export const Con = styled.div`
  width: 100%;
  padding: 50px 0px;
`;

export const SecviseContainer = styled.div`
  width: 100%;
  padding: 50px 0px;
  & h1 {
    text-align: center;
  }
`;
