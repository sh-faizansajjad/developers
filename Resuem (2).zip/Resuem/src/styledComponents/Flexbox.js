import styled from "styled-components";

export const FlexWrap = styled.div`
  width: 100%;
  padding: 40px;
  display: flex;
  justify-content: center;
  flex-wrap: wrap;

  & > div {
    width: 30%;
    height: 400px;
    margin: 0px 10px px 10px;
    & h3,
    p {
      text-align: center;
    }
  }

  @media only screen and (max-width: 768px) {
    padding: 5px;
  }
`;
export const AboutFlex = styled.div`
  width: 100%;
  padding: 50px 0px;
  display: flex;
  justify-content: center;
  align-items: center;
  & > div {
    width: 40%;
    margin: 10px;
  }
  & > .info {
    padding: 20px;
    & h1,
    p {
      padding: 20px 0px;
    }
  }

  @media only screen and (max-width: 768px) {
    flex-direction: column;
    & > div {
      width: 80%;
    }
  } ;
`;

export const ServiceFlex = styled.div`
  width: 100%;
  padding: 20px 0px;
  display: flex;
  justify-content: center;
  align-items: center;
  & div {
    width: 30%;
    padding: 50px;
    text-align: center;
    margin: 10px;
    background-color: ${(props) => props.theme.boxColor};
    border-radius: 10px;
    & h3,
    p {
      padding: 20px;
    }
  }
  @media only screen and (max-width: 768px) {
    flex-direction: column;
    & div {
      border-radius: 10px;
      width: 70%;
      padding: 5px;
    }
  }
`;

export const Flex = styled.div`
  width: 100%;
  padding: 20px 0px;
  display: flex;
  justify-content: center;
  align-items: center;

  & .form {
    width: 50%;
    height: 550px;
    padding: 10px;
    margin: 10px;
    & input {
      width: 95%;
      height: 40px;
      margin: 10px;
      border-radius: 5px;
      border: none;
      padding: 10px;
      background-color: ${(props) => props.theme.boxColor};
    }
    & textarea {
      border-radius: 5px;
      border: none;
      padding: 10px;
      margin: 10px;
      background-color: ${(props) => props.theme.boxColor};
    }
  }
  & .detail {
    width: 30%;
    height: 550px;
    padding: 20px;
    margin: 10px;
  }
  & div {
    padding: 20px 0px;
  }

  @media only screen and (max-width: 768px) {
    flex-direction: column;
    & .form {
      width: 85%;
    }

    & .detail {
      width: 85%;
    }
  }

  @media only screen and (max-width: 1024px) {
    & .form {
      width: 65%;
    }

    & .detail {
      width: 50%;
    }
  } ;
`;

export const FooterBox = styled.div`
  width: 100%;
  padding: 20px 0px;
  display: flex;
  justify-content: space-around;
  align-items: center;
  flex-direction: column;
  & div {
    margin: 10px;
    width: 80%;
    text-align: center;
    & .links {
      width: 70px;
      height: 70px;
      background-color: ${(props) => props.theme.boxColor};
      border-radius: 35px;
      padding: 20px;
      display: inline-block;
    }
  }
`;
