import styled from "styled-components";

export const Button = styled.button`
  width: 150px;
  height: 40px;
  background-color: ${(props) => props.theme.btnBgClr1};
  color: white;
  border: none;
  border-radius: 20px;
  padding: 10px;
  text-align-center;
  margin : 3px;
  &:hover {
    background-color: white;
    color: black;  }
  }
`;

export const ButtonTwo = styled.button`
  width: 150px;
  height: 40px;
  background-color: ${(props) => props.theme.btnBgClr};
  color: white;
  border: none;
  border-radius: 20px;
  padding: 10px;
  text-align-center;
  margin : 3px;
  &:hover {
    background-color: white;
    color: black;  }
  }
`;

export const ThemeBtn = styled.button`
  width: 150px;
  height: 40px;
  border: none;
  border-radius: 20px;
  padding: 10px;
  text-align-center;
  margin : 3px;
  
`;
