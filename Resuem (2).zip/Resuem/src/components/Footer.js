import React from "react";
import { Con } from "../styledComponents/containers";
import { FooterBox } from "../styledComponents/Flexbox";

const Footer = () => {
  return (
    <>
      <Con>
        <FooterBox>
          <div>
            <h4>
              Copyright © 2023 All rights reserved | This template is made with
              by Colorlib
            </h4>
          </div>
          <div>
            <div className="links">
              <p>FB</p>
            </div>
            <div className="links">
              <p>IN</p>
            </div>
            <div className="links">
              <p>Li</p>
            </div>
            <div className="links">
              <p>UP</p>
            </div>
          </div>
        </FooterBox>
      </Con>
    </>
  );
};

export default Footer;
