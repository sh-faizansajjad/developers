import * as Yup from "yup";

export const validationSchema = Yup.object({
  name: Yup.string().required("Name is required"),
  email: Yup.string().email().required("email is required"),
  contact: Yup.number().required("Number is required"),
});
