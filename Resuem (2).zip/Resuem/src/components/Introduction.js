import React from "react";
import { Container } from "../styledComponents/containers";

const Introduction = () => {
  return (
    <>
      <Container>
        <div className="menu">
          <ul>
            <li>HOME</li>
            <li>PORTFOLIO</li>
            <li>RESUME</li>
            <li>ABOUT</li>
            <li>CONTACT</li>
          </ul>
        </div>
        <div className="text">
          <h3>Hello, I'm</h3>
          <h1>Charles Anderson</h1>
          <p>AND THIS IS MY REZUME</p>
        </div>
      </Container>
    </>
  );
};

export default Introduction;
