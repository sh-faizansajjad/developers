import { useFormik } from "formik";
import React from "react";
import { Button } from "../styledComponents/Button.style";
import { SecviseContainer } from "../styledComponents/containers";
import { Flex } from "../styledComponents/Flexbox";
import { validationSchema } from "../components/validate/FormValidate";
const GetTouch = () => {
  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      contact: "",
      message: "",
    },
    onSubmit: (values, actions) => {
      console.log(" form data", values);
      actions.resetForm();
    },
    validationSchema,
  });

  console.log("form values", formik.values);
  return (
    <>
      <SecviseContainer>
        <h1>Get In Touch</h1>
        <Flex>
          <div className="form">
            <h1>Get In Touch</h1>
            <form onSubmit={formik.handleSubmit}>
              <input
                type="text"
                name="name"
                placeholder="Your Name"
                value={formik.values.name}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.name && formik.touched.name ? (
                <>{formik.errors.name}</>
              ) : null}

              <input
                type="email"
                name="email"
                placeholder="Your Email"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.email && formik.touched.email ? (
                <>{formik.errors.email}</>
              ) : null}
              <input
                type="text"
                name="contact"
                placeholder="Your Number"
                value={formik.values.contact}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.contact && formik.touched.contact ? (
                <>{formik.errors.contact}</>
              ) : null}
              <textarea
                rows="15"
                cols="80"
                name="message"
                form="usrform"
                placeholder="Write a Message"
                value={formik.values.message}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              <Button>Submit</Button>
            </form>
          </div>
          <div className="detail">
            <h1>My Contact Details</h1>
            <div>
              <h4>EMAIL</h4>
              <p>site@gmail.com</p>
            </div>

            <div>
              <h4>PHONE</h4>
              <p>+30 976 1382 9921</p>
            </div>

            <div>
              <h4>FAX</h4>
              <p>+30 976 1382 9922</p>
            </div>

            <div>
              <h4>ADDRESS</h4>
              <p>
                San Francisco, CA <br />
                4th Floor8 Lower <br />
                San Francisco street, M1 50F
              </p>
            </div>
          </div>
        </Flex>
      </SecviseContainer>
    </>
  );
};

export default GetTouch;
