import React from "react";
import { Button, ButtonTwo } from "../styledComponents/Button.style";
import { Con } from "../styledComponents/containers";
import { AboutFlex } from "../styledComponents/Flexbox";
import { AboutImage } from "../styledComponents/Img.styled";
import { intro } from "../utils";
const AboutMe = () => {
  return (
    <>
      <Con>
        <AboutFlex>
          <div className="img">
            <AboutImage src={intro} />
          </div>
          <div className="info">
            <h1>About Me</h1>
            <p>
              Separated they live in Bookmarksgrove right at the coast of the
              Semantics, a large language ocean.
            </p>
            <p>
              A small river named Duden flows by their place and supplies it
              with the necessary regelialia. It is a paradisematic country, in
              which roasted parts of sentences fly into your mouth.
            </p>
            <Button> HIRE ME</Button>
            <ButtonTwo>DOWNLOAD CV</ButtonTwo>
          </div>
        </AboutFlex>
      </Con>
    </>
  );
};

export default AboutMe;
