import React from "react";
import { SecviseContainer } from "../styledComponents/containers";
import { ServiceFlex } from "../styledComponents/Flexbox";

const Services = () => {
  return (
    <>
      <SecviseContainer>
        <h1>My Services</h1>
        <ServiceFlex>
          <div>
            <h3>Web Design</h3>
            <p>
              Far far away, behind the word mountains, far from the countries
              Vokalia and Consonantia, there live the blind texts. Separated
              they live in Bookmarksgrove right at the coast of the Semantics, a
              large language ocean.
            </p>
          </div>
          <div>
            <h3>Search Engine Optimization</h3>
            <p>
              A small river named Duden flows by their place and supplies it
              with the necessary regelialia. It is a paradisematic country, in
              which roasted parts of sentences fly into your mouth.
            </p>
          </div>
          <div>
            <h3>Video Editing</h3>
            <p>
              Even the all-powerful Pointing has no control about the blind
              texts it is an almost unorthographic life One day however a small
              line of blind text by the name of Lorem Ipsum decided to leave for
              the far World of Grammar.
            </p>
          </div>
        </ServiceFlex>
      </SecviseContainer>
    </>
  );
};

export default Services;
