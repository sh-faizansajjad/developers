import React from "react";
import { SecviseContainer } from "../styledComponents/containers";
import { ServiceFlex } from "../styledComponents/Flexbox";
import { Image } from "../styledComponents/Img.styled";
import { blog1, blog2, blog3 } from "../utils";

const Blogs = () => {
  return (
    <>
      <SecviseContainer>
        <h1>Blog on Medium</h1>
        <ServiceFlex>
          <div>
            <Image src={blog1} />
            <h3>Creative Product Designer From Facebook </h3>
            <p>
              Even the all-powerful Pointing has no control about the blind
              texts it is an almost unorthographic.
            </p>
          </div>
          <div>
            <Image src={blog2} />
            <h3>Creative Product Designer From Facebook </h3>
            <p>
              Even the all-powerful Pointing has no control about the blind
              texts it is an almost unorthographic.
            </p>
          </div>
          <div>
            <Image src={blog3} />
            <h3>Creative Product Designer From Facebook </h3>
            <p>
              Even the all-powerful Pointing has no control about the blind
              texts it is an almost unorthographic.
            </p>
          </div>
        </ServiceFlex>
      </SecviseContainer>
    </>
  );
};

export default Blogs;
