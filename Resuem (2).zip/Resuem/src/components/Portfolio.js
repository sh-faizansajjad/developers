import React from "react";
import { ContainerPadding } from "../styledComponents/containers";
import { FlexWrap } from "../styledComponents/Flexbox";
import { Image } from "../styledComponents/Img.styled";
import { box1, box2, box3, box4, box5, box6 } from "../utils";
const Portfolio = () => {
  return (
    <>
      <ContainerPadding>
        <div>
          <h1>Featured Portfolio</h1>
        </div>
        <div className="portfolioName">
          <ul>
            <li>All</li>
            <li>Packing</li>
            <li>MockUp</li>
            <li>Typography</li>
            <li>PhotoGraphy</li>
          </ul>
        </div>
        <FlexWrap>
          <div>
            <Image src={box1} alt="pic" />
            <h3>Square Box Mockup</h3>
            <p>MOCKUP</p>
          </div>
          <div>
            <Image src={box2} alt="pic" />
            <h3>Product Box Package Mockup</h3>
            <p>MOCKUP</p>
          </div>
          <div>
            <Image src={box3} alt="pic" />
            <h3>Creative Package Design</h3>
            <p>PACKING</p>
          </div>
          <div>
            <Image src={box4} alt="pic" />
            <h3>Packaging Brand</h3>
            <p>PACKING</p>
          </div>
          <div>
            <Image src={box5} alt="pic" />
            <h3>Isometric 3D Extrusion</h3>
            <p>TYPOGRAPHY</p>
          </div>
          <div>
            <Image src={box6} alt="pic" />
            <h3>White Space Photography</h3>
            <p>TYPOGRAPHY</p>
          </div>
        </FlexWrap>
      </ContainerPadding>
    </>
  );
};

export default Portfolio;
